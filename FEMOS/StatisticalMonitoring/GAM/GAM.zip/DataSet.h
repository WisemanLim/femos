// DataSet.h: interface for the CDataSet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATASET_H__C8763E3D_9D4E_4FCC_80FE_41F57F142DF4__INCLUDED_)
#define AFX_DATASET_H__C8763E3D_9D4E_4FCC_80FE_41F57F142DF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataSet  
{
public:
	CDataSet();
	virtual ~CDataSet();
	float m_fValue;
	float m_fPoint;
};

#endif // !defined(AFX_DATASET_H__C8763E3D_9D4E_4FCC_80FE_41F57F142DF4__INCLUDED_)
