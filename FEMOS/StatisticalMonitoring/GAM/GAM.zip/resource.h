//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GAM.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GAMTYPE                     129
#define IDD_DIALOG_PROPERTIES           130
#define IDB_TILE                        131
#define IDD_DIALOG_ADDCHILDS            132
#define IDD_DIALOG_LINKPROPER           133
#define IDD_DIALOG_OPTION               134
#define IDB_SPLASH                      135
#define IDD_SPLASH                      136
#define IDC_EDIT_ITEMNO                 1000
#define ID_EDIT_WINDOW                  1001
#define IDC_SPIN_ITEMNO                 1002
#define IDC_PROGRESS_SPLASH             1003
#define IDC_RADIO_SUM                   1004
#define IDC_STATIC_PROGRESS             1005
#define IDC_EDIT_NAME                   1006
#define IDC_EDIT_ID                     1007
#define IDC_EDIT_LEVEL                  1008
#define IDC_EDIT_VALUE                  1009
#define IDC_EDIT_CHILD_NAME             1010
#define IDC_EDIT_DEPTH                  1011
#define IDC_EDIT_PARENT_NAME            1012
#define IDC_RADIO_ASCENDING             1013
#define IDC_GRID                        1014
#define IDC_RADIO_DESCENDING            1015
#define ID_INSERT_ALTER                 1016
#define IDC_RADIO_ACCELUP               1017
#define ID_DELETE_ALTER                 1018
#define IDC_RADIO_ACCELDOWN             1019
#define ID_CURRENT_ALTER                1020
#define IDC_SPIN_DEPTH                  1021
#define ID_EDIT_LABEL                   1022
#define ID_OBJECT_GRAPH                 1023
#define ID_FONT_COMBO                   1024
#define ID_COMBO_GRAPHTYPE              1025
#define ID_COMBO_GRAPHEFFECT            1026
#define ID_COMBO_GRAPHITEMID            1027
#define ID_COMBO_DATA                   1028
#define ID_EDIT_CALCULATE               32771
#define ID_EDIT_ADDCHILD                32772
#define ID_EDIT_ADDCHILDS               32773
#define ID_EDIT_ADDLINK                 32774
#define ID_EDIT_REMOVEITEM              32775
#define ID_EDIT_TEXTEDIT                32776
#define ID_EDIT_PROPERTIES              32777
#define ID_VIEW_GRID                    32778
#define ID_VIEW_CHANGEFONT              32779
#define ID_VIEW_MINIMAP                 32780
#define ID_VIEW_RESULT                  32781
#define ID_VIEW_GRAPH                   32782
#define ID_VIEW_DATA                    32783
#define ID_VIEW_BOLD                    32784
#define ID_VIEW_ITALIC                  32785
#define ID_VIEW_UNDERLINE               32786
#define ID_VIEW_ONGRAPH                 32787
#define ID_TOOL_OPTION                  32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
